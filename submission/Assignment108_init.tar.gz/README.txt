Name: Saljooq Altaf
Net ID: saltaf


Assignment 1.08


This is a continuation of 1.01-1.07.

This program has an object_parser and find_dice implemented. Also, most of the functions previously used
to instantiate the npc with random variables now used the parsed data in the
monster_description vector (called monsters).

Additionally, print methods have been updated to use colors in the description (other than the
debugging 'g' key used for teleporting and debugging.)

The monster list also has colors.
